#!/usr/bin/env python3
"""
xml_to_json.py  -  generic, mapping-driven converter: Cleo XML  ->  structured JSON

The program has NO built-in knowledge of partners or certificates.
What gets produced is defined entirely by a mapping file (JSON), so the same
program handles partner creation, certificates, or any other XML export:

    python xml_to_json.py -m mappings/partner_mapping.json     -i xml_input  -o json_output
    python xml_to_json.py -m mappings/certificate_mapping.json -i cert_input -o json_output

MAPPING FILE
  {"name": "partner", "template": { ...the JSON you want to produce... }}

  Inside "template", every string that starts with $ is a source expression.
  Anything else (numbers, true/false, plain strings) is copied as-is.
  Write $$ to output a literal string that starts with $.

SOURCE EXPRESSIONS     $<path> [| filter] [| filter] ...
  $Host.Mailbox.Action.Commands   absolute path from the document root (dot separated)
  $Host@alias                     attribute of an element
  $.Address   $@alias   $.        relative to the current element (see $foreach)
  Mailbox[0]  Mailbox[*]          pick one by index (0-based) / all matches as a list
  $#file                          name of the source file

  Filters: strip upper lower int float bool count split_commands
           index:N  join:SEP  split:SEP  default:VALUE
  e.g.   "$.Commands | split_commands | index:1"   -> second command

LISTS / NESTING
  {"$foreach": "$Host", "$item": { ...template evaluated once per Host... }}
  Inside $item, paths starting with "$." or "$@" are relative to that Host, and
  $foreach can be nested (Host -> Mailbox -> Action).
"""
import argparse
import json
import re
import sys
from pathlib import Path

from lxml import etree

EXTENSIONS = {".xml", ".txt"}
SRC_ATTR = "_source_file"
SEG = re.compile(r"^(?P<name>[^\[\]@]*)(?:\[(?P<idx>\*|\d+)\])?(?:@(?P<attr>[\w\-:]+))?$")
VERB = re.compile(r"^[A-Z][A-Z_]*$")


# ------------------------------------------------------------ XML loading
def repair_text(raw):
    """Fix common Cleo export problems (missing closing quote, bare &)."""
    notes = []
    fixed, n = re.subn(r'(\w+="[^"<>\n]*)(\n\s*\w+=")', r'\1"\2', raw)
    if n:
        notes.append(f"closed {n} unterminated attribute quote(s)")
    fixed, n = re.subn(r'&(?!(?:amp|lt|gt|quot|apos|#\d+|#x[0-9A-Fa-f]+);)', '&amp;', fixed)
    if n:
        notes.append(f"escaped {n} bare '&'")
    return fixed, notes


def load_xml(path):
    raw = path.read_bytes().decode("utf-8-sig", errors="replace").strip()
    fixed, notes = repair_text(raw)
    data = fixed.encode("utf-8")
    try:
        return etree.fromstring(data, etree.XMLParser(remove_comments=True)), notes
    except etree.XMLSyntaxError as err:
        root = etree.fromstring(data, etree.XMLParser(recover=True, remove_comments=True))
        if root is None:
            raise
        return root, notes + [f"recovered with errors: {err}"]


def find_files(folder, recursive):
    it = folder.rglob("*") if recursive else folder.glob("*")
    return sorted(p for p in it if p.is_file() and p.suffix.lower() in EXTENSIONS)


def local(el):
    return etree.QName(el).localname


# ------------------------------------------------------------ path engine
def split_commands(text):
    """'CONNECT PUT -DEL -X' -> ['CONNECT', 'PUT -DEL -X']  (verb = UPPERCASE word, no dash)."""
    out = []
    for line in re.split(r"[\r\n]+", text or ""):
        for tok in line.split():
            if VERB.match(tok) or not out:
                out.append(tok)
            else:
                out[-1] += " " + tok
    return out


def source_file(el):
    top = el
    for top in [el] + list(el.iterancestors()):
        if top.get(SRC_ATTR):
            return top.get(SRC_ATTR)
    return None


def walk_path(path, ctx, root):
    """Return (nodes_or_strings, want_list, is_attr_result)."""
    if path.startswith("."):
        nodes, path = [ctx], path[1:]
    elif path.startswith("@"):
        nodes = [ctx]
    else:
        nodes = [root]
    want_list, attr_result = False, False
    segments = [s for s in re.split(r"\.(?![^\[]*\])", path) if s != ""] or [""]
    for s in segments:
        m = SEG.match(s)
        if not m:
            raise ValueError(f"Bad path segment '{s}' in '{path}'")
        name, idx, attr = m.group("name"), m.group("idx"), m.group("attr")
        if name:
            nodes = [c for n in nodes for c in n if isinstance(c.tag, str) and local(c) == name]
        if idx == "*":
            want_list = True
        elif idx is not None:
            i = int(idx)
            nodes = [nodes[i]] if i < len(nodes) else []
        if attr:
            nodes = [n.get(attr) for n in nodes if n.get(attr) is not None]
            attr_result = True
    return nodes, want_list, attr_result


def to_text(item, attr_result):
    return item.strip() if attr_result else (item.text or "").strip()


def truthy(v):
    return str(v).strip().lower() in ("true", "yes", "y", "1", "on")


def apply_filter(value, spec):
    name, _, arg = spec.partition(":")
    name = name.strip()
    if name == "count":
        return len(value) if isinstance(value, list) else (0 if value is None else 1)
    if name == "split_commands":
        return split_commands(value if isinstance(value, str) else "")
    if name == "index":
        i = int(arg)
        return value[i] if isinstance(value, list) and -len(value) <= i < len(value) else None
    if name == "join":
        return arg.join(map(str, value)) if isinstance(value, list) else value
    if name == "default":
        return arg if value in (None, "", []) else value
    if value is None:
        return None
    if isinstance(value, list):
        return [apply_filter(v, spec) for v in value]
    if name == "strip": return str(value).strip()
    if name == "upper": return str(value).upper()
    if name == "lower": return str(value).lower()
    if name == "int":
        try: return int(float(value))
        except ValueError: return None
    if name == "float":
        try: return float(value)
        except ValueError: return None
    if name == "bool": return truthy(value)
    if name == "split": return [p.strip() for p in str(value).split(arg) if p.strip()]
    raise ValueError(f"Unknown filter '{name}'")


def evaluate(expr, ctx, root):
    parts = [p.strip() for p in expr[1:].split("|")]
    path, filters = parts[0], parts[1:]
    if path == "#file":
        value = source_file(ctx)
    else:
        nodes, want_list, attr_result = walk_path(path, ctx, root)
        if want_list:
            value = [to_text(n, attr_result) for n in nodes]
        else:
            value = to_text(nodes[0], attr_result) if nodes else None
        if filters and filters[0] == "count" and not want_list:
            value = nodes  # count what matched, not the first text
    for f in filters:
        value = apply_filter(value, f)
    return value


def render(t, ctx, root):
    if isinstance(t, dict):
        if "$foreach" in t:
            nodes, _, attr = walk_path(t["$foreach"][1:], ctx, root)
            return [render(t["$item"], n, root) for n in nodes]
        return {k: render(v, ctx, root) for k, v in t.items()
                if not k.startswith("//") and not k.startswith("_note")}
    if isinstance(t, list):
        return [render(x, ctx, root) for x in t]
    if isinstance(t, str):
        if t.startswith("$$"):
            return t[1:]
        if t.startswith("$"):
            return evaluate(t, ctx, root)
    return t


def prune(v):
    """Drop null values (and objects that end up empty)."""
    if isinstance(v, dict):
        out = {k: prune(x) for k, x in v.items()}
        return {k: x for k, x in out.items() if x is not None and x != {}}
    if isinstance(v, list):
        return [prune(x) for x in v]
    return v


# ------------------------------------------------------------------- main
def build_root(files, log):
    """Virtual root element holding the top element of every input file."""
    root = etree.Element("__root__")
    for p in files:
        try:
            el, notes = load_xml(p)
        except Exception as err:  # noqa
            log.append((p.name, "FAILED", str(err)))
            print(f"[FAILED]   {p.name}: {err}")
            continue
        el.set(SRC_ATTR, p.name)
        root.append(el)
        log.append((p.name, "REPAIRED" if notes else "OK", "; ".join(notes)))
        print(f"[{'REPAIRED' if notes else 'OK':8}] {p.name}" + (f"  ({'; '.join(notes)})" if notes else ""))
    return root


def write_json(obj, path):
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"  -> {path}")


def main():
    ap = argparse.ArgumentParser(description="Mapping-driven XML -> JSON converter")
    ap.add_argument("-m", "--mapping", default=str(Path(__file__).parent / "mappings" / "partner_mapping.json"),
                    help="mapping JSON file (default: mappings/partner_mapping.json)")
    ap.add_argument("-i", "--input", default="xml_input", help="folder with XML files")
    ap.add_argument("-o", "--output", default="json_output", help="output folder")
    ap.add_argument("--mode", choices=["combined", "per-file"], default="combined",
                    help="combined: one JSON for all files (default); per-file: one JSON per input file")
    ap.add_argument("-r", "--recursive", action="store_true")
    ap.add_argument("--keep-null", action="store_true", help="keep fields whose value is null")
    args = ap.parse_args()

    mapping = json.loads(Path(args.mapping).read_text(encoding="utf-8"))
    template, name = mapping["template"], mapping.get("name", Path(args.mapping).stem)
    folder, out = Path(args.input), Path(args.output)
    if not folder.is_dir():
        sys.exit(f"Input folder not found: {folder}")
    files = find_files(folder, args.recursive)
    if not files:
        sys.exit(f"No .xml/.txt files in {folder}")
    out.mkdir(parents=True, exist_ok=True)

    log = []
    finish = (lambda x: x) if args.keep_null else prune
    if args.mode == "combined":
        root = build_root(files, log)
        write_json(finish(render(template, root, root)), out / f"{name}.json")
    else:
        for p in files:
            root = build_root([p], log)
            if len(root):
                write_json(finish(render(template, root, root)), out / f"{p.stem}.{name}.json")

    failed = sum(1 for _, s, _ in log if s == "FAILED")
    print(f"\nDone. {len(log) - failed} file(s) converted, {failed} failed.")


if __name__ == "__main__":
    main()