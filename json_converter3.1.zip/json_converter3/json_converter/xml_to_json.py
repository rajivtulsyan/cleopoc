#!/usr/bin/env python3
"""
xml_to_json.py  -  generic, mapping-driven converter: Cleo XML  ->  structured JSON

The program has NO built-in knowledge of partners or certificates.
What gets produced is defined entirely by a mapping file (JSON), so the same
program handles partner creation, certificates, or any other XML export:

    python xml_to_json.py                       # AUTO-DETECT: each file picks its own mapping
    python xml_to_json.py -i my_xml -o my_json
    python xml_to_json.py -m mappings/add_partner.json   # force ONE mapping for all files
    python xml_to_json.py --dry-run --explain   # only show which mapping each file would use, and why
    python xml_to_json.py --operation update    # use the update_* mappings instead of create_*

AUTO-DETECTION  (exactly ONE mapping is chosen per input file)
  Every mapping in mappings/ has a "match" block describing the XML it is for.
  For each file the program checks all mappings, throws out the ones whose
  conditions fail, and uses the single best one (highest priority, then the most
  conditions satisfied):
    "match": {
      "root":      "Host",                      # top-level element name (or list of names)
      "paths_all": ["Host.Mailbox"],            # every path must exist
      "paths_any": ["A.B", "C.D@attr"],         # at least one path must exist
      "counts":    {"Host": {"min": 2}},        # how many elements: min and/or max
      "operation": "create",                    # only when run with --operation create|update
      "priority":  10                           # optional tie-breaker, higher wins
    }
  Examples shipped: 1 Host in the file -> add_partner, 2+ Hosts -> create_bulk_partners
  (with --operation update: update_partner / update_bulk_partners).
  A Certificates file -> create_certificate (update_certificate with --operation update).
  Use --explain to see why each mapping was accepted or rejected, --all-matches to
  run every mapping that fits instead of only the best one.
  Files that match no mapping are reported as UNMATCHED and skipped.
  Mapping files whose name starts with "_" are ignored (use them as templates).
  Optional "split": "$Certificates.Certificate" makes a mapping write one JSON
  per matching element (for single-object API calls); inside its template use
  paths relative to that element ($@alias, $.Subject ...).
  OUTPUT NAMES: <input file name>_<mapping name>.json   e.g. abc_van_add_partner.json
  (with --mode combined all files are treated as ONE document: combined_<mapping>.json)
"""
import argparse
import copy
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

from lxml import etree

EXTENSIONS = {".xml", ".txt"}
SRC_ATTR = "_source_file"
SEG = re.compile(r"^(?P<name>[^\[\]@]*)(?:\[(?P<idx>\*|\d+)\])?(?:@(?P<attr>[\w\-:]+))?$")
VERB = re.compile(r"^[A-Z][A-Z_]*$")


# ------------------------------------------------------------ XML loading
def repair_text(raw):
    """Fix common Cleo export problems (missing closing quote, bare &)."""
    notes = []
    fixed, n = re.subn(r'(\w+="[^"<>\n]*)(\n\s*\w+=")', r'\1"\2', raw)
    if n:
        notes.append(f"closed {n} unterminated attribute quote(s)")
    fixed, n = re.subn(r'&(?!(?:amp|lt|gt|quot|apos|#\d+|#x[0-9A-Fa-f]+);)', '&amp;', fixed)
    if n:
        notes.append(f"escaped {n} bare '&'")
    return fixed, notes


def load_xml(path):
    raw = path.read_bytes().decode("utf-8-sig", errors="replace").strip()
    fixed, notes = repair_text(raw)
    data = fixed.encode("utf-8")
    try:
        return etree.fromstring(data, etree.XMLParser(remove_comments=True)), notes
    except etree.XMLSyntaxError as err:
        root = etree.fromstring(data, etree.XMLParser(recover=True, remove_comments=True))
        if root is None:
            raise
        return root, notes + [f"recovered with errors: {err}"]


def find_files(folder, recursive):
    it = folder.rglob("*") if recursive else folder.glob("*")
    return sorted(p for p in it if p.is_file() and p.suffix.lower() in EXTENSIONS)


def local(el):
    return etree.QName(el).localname


# ------------------------------------------------------------ path engine
def split_commands(text):
    """'CONNECT PUT -DEL -X' -> ['CONNECT', 'PUT -DEL -X']  (verb = UPPERCASE word, no dash)."""
    out = []
    for line in re.split(r"[\r\n]+", text or ""):
        for tok in line.split():
            if VERB.match(tok) or not out:
                out.append(tok)
            else:
                out[-1] += " " + tok
    return out


def source_file(el):
    top = el
    for top in [el] + list(el.iterancestors()):
        if top.get(SRC_ATTR):
            return top.get(SRC_ATTR)
    return None


def walk_path(path, ctx, root):
    """Return (nodes_or_strings, want_list, is_attr_result)."""
    descend = False
    if path.startswith("//"):          # //Name = Name anywhere below the start point
        nodes, path, descend = [root], path[2:], True
    elif path.startswith("."):
        nodes, path = [ctx], path[1:]
    elif path.startswith("@"):
        nodes = [ctx]
    else:
        nodes = [root]
    want_list, attr_result = False, False
    segments = [s for s in re.split(r"\.(?![^\[]*\])", path) if s != ""] or [""]
    for pos, s in enumerate(segments):
        m = SEG.match(s)
        if not m:
            raise ValueError(f"Bad path segment '{s}' in '{path}'")
        name, idx, attr = m.group("name"), m.group("idx"), m.group("attr")
        if name and descend and pos == 0:
            nodes = [d for n in nodes for d in n.iterdescendants() if isinstance(d.tag, str) and local(d) == name]
        elif name:
            nodes = [c for n in nodes for c in n if isinstance(c.tag, str) and local(c) == name]
        if idx == "*":
            want_list = True
        elif idx is not None:
            i = int(idx)
            nodes = [nodes[i]] if i < len(nodes) else []
        if attr:
            nodes = [n.get(attr) for n in nodes if n.get(attr) is not None]
            attr_result = True
    return nodes, want_list, attr_result


def to_text(item, attr_result):
    return item.strip() if attr_result else (item.text or "").strip()


def truthy(v):
    return str(v).strip().lower() in ("true", "yes", "y", "1", "on")


DATE_FORMATS = ["%Y/%m/%d %H:%M:%S", "%Y/%m/%d %H:%M", "%Y/%m/%d", "%Y-%m-%d %H:%M:%S",
                "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y"]


def to_epoch(value, millis):
    v = str(value).strip().replace("Z", "")
    for fmt in DATE_FORMATS:
        try:
            ts = datetime.strptime(v, fmt).replace(tzinfo=timezone.utc).timestamp()
            return int(ts * 1000) if millis else int(ts)
        except ValueError:
            continue
    return None


def apply_filter(value, spec):
    name, _, arg = spec.partition(":")
    name = name.strip()
    if name == "count":
        return len(value) if isinstance(value, list) else (0 if value is None else 1)
    if name == "split_commands":
        return split_commands(value if isinstance(value, str) else "")
    if name == "index":
        i = int(arg)
        return value[i] if isinstance(value, list) and -len(value) <= i < len(value) else None
    if name == "join":
        return arg.join(map(str, value)) if isinstance(value, list) else value
    if name == "default":
        return arg if value in (None, "", []) else value
    if value is None:
        return None
    if isinstance(value, list):
        return [apply_filter(v, spec) for v in value]
    if name == "strip": return str(value).strip()
    if name == "upper": return str(value).upper()
    if name == "lower": return str(value).lower()
    if name == "int":
        try: return int(float(value))
        except ValueError: return None
    if name == "float":
        try: return float(value)
        except ValueError: return None
    if name == "bool": return truthy(value)
    if name == "epoch_ms": return to_epoch(value, True)
    if name == "epoch_s": return to_epoch(value, False)
    if name == "split": return [p.strip() for p in str(value).split(arg) if p.strip()]
    raise ValueError(f"Unknown filter '{name}'")


def evaluate(expr, ctx, root):
    parts = [p.strip() for p in expr[1:].split("|")]
    path, filters = parts[0], parts[1:]
    if path == "#file":
        value = source_file(ctx)
    else:
        nodes, want_list, attr_result = walk_path(path, ctx, root)
        if want_list:
            value = [to_text(n, attr_result) for n in nodes]
        else:
            value = to_text(nodes[0], attr_result) if nodes else None
        if filters and filters[0] == "count" and not want_list:
            value = nodes  # count what matched, not the first text
    for f in filters:
        value = apply_filter(value, f)
    return value


def render(t, ctx, root):
    if isinstance(t, dict):
        if "$foreach" in t:
            nodes, _, attr = walk_path(t["$foreach"][1:], ctx, root)
            return [render(t["$item"], n, root) for n in nodes]
        return {k: render(v, ctx, root) for k, v in t.items()
                if not k.startswith("//") and not k.startswith("_note")}
    if isinstance(t, list):
        return [render(x, ctx, root) for x in t]
    if isinstance(t, str):
        if t.startswith("$$"):
            return t[1:]
        if t.startswith("$"):
            return evaluate(t, ctx, root)
    return t


def prune(v):
    """Drop null values (and objects that end up empty)."""
    if isinstance(v, dict):
        out = {k: prune(x) for k, x in v.items()}
        return {k: x for k, x in out.items() if x is not None and x != {}}
    if isinstance(v, list):
        return [prune(x) for x in v]
    return v


# ------------------------------------------------------------- detection
def as_list(v):
    return v if isinstance(v, list) else [v]


def evaluate_match(match, root, operation):
    """Return (accepted, score, reasons). Rejected -> (False, None, [why not])."""
    if not match:
        return False, None, ["no 'match' block"]
    why = []
    if "operation" in match:
        ops = as_list(match["operation"])
        if operation not in ops:
            return False, None, [f"needs operation {'/'.join(ops)} but running '{operation}'"]
        why.append(f"operation={operation}")
    if "root" in match:
        tops = {local(c) for c in root if isinstance(c.tag, str)}
        names = as_list(match["root"])
        if not tops & set(names):
            return False, None, [f"top element is <{', '.join(sorted(tops))}>, needs <{'/'.join(names)}>"]
        why.append(f"root={'/'.join(sorted(tops & set(names)))}")
    for p in match.get("paths_all", []):
        if not walk_path(p, root, root)[0]:
            return False, None, [f"path '{p}' not found"]
        why.append(f"has {p}")
    any_paths = match.get("paths_any", [])
    if any_paths:
        found = [p for p in any_paths if walk_path(p, root, root)[0]]
        if not found:
            return False, None, [f"none of {any_paths} found"]
        why.append(f"has {found[0]}")
    for path, lim in match.get("counts", {}).items():
        n = len(walk_path(path, root, root)[0])
        lo, hi = lim.get("min"), lim.get("max")
        if lo is not None and n < lo:
            return False, None, [f"{path} count is {n}, needs at least {lo}"]
        if hi is not None and n > hi:
            return False, None, [f"{path} count is {n}, needs at most {hi}"]
        why.append(f"{path} count={n}")
    if not why:
        return False, None, ["'match' block has no conditions"]
    return True, (match.get("priority", 0), len(why)), why


def choose(doc_root, mappings, operation):
    """Return (accepted [(mapping, reasons)] best first, rejected [(name, reason)])."""
    ok, no = [], []
    for m in mappings:
        accepted, score, info = evaluate_match(m.get("match"), doc_root, operation)
        if accepted:
            ok.append((score, m, info))
        else:
            no.append((m["name"], info[0]))
    ok.sort(key=lambda x: (-x[0][0], -x[0][1], x[1]["name"]))
    return [(m, info, sc) for sc, m, info in ok], no


def load_mappings(path):
    """path = one mapping file (forced) or a folder of mapping files (auto-detect)."""
    files = [path] if path.is_file() else sorted(p for p in path.glob("*.json") if not p.name.startswith("_"))
    out = []
    for f in files:
        try:
            m = json.loads(f.read_text(encoding="utf-8"))
        except json.JSONDecodeError as err:
            print(f"[WARN] {f.name}: invalid JSON, skipped ({err})")
            continue
        if "template" not in m:
            print(f"[WARN] {f.name}: no 'template', skipped")
            continue
        m.setdefault("name", f.stem)
        if path.is_dir() and not m.get("match"):
            print(f"[WARN] {f.name}: no 'match' block, it can only be used with -m")
        out.append(m)
    return out


# ------------------------------------------------------------------- main
def write_json(obj, path):
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"  -> {path}")


def main():
    here = Path(__file__).parent
    ap = argparse.ArgumentParser(description="Mapping-driven XML -> JSON converter with auto-detection")
    ap.add_argument("-m", "--mapping", default=str(here / "mappings"),
                    help="mapping folder (auto-detect, default) or ONE mapping file (forces it for every file)")
    ap.add_argument("-i", "--input", default="xml_input", help="folder with XML files")
    ap.add_argument("-o", "--output", default="json_output", help="output folder")
    ap.add_argument("--operation", choices=["create", "update"], default="create",
                    help="which kind of API call to prepare (default: create)")
    ap.add_argument("--mode", choices=["per-file", "combined"], default="per-file",
                    help="per-file (default): <file>_<mapping>.json for every input file; "
                         "combined: treat ALL files of the same type as ONE document -> combined_<mapping>.json")
    ap.add_argument("--only", help="comma separated mapping names allowed, e.g. add_partner,create_certificate")
    ap.add_argument("--all-matches", action="store_true",
                    help="run every mapping that fits a file instead of only the best one")
    ap.add_argument("--explain", action="store_true", help="show why mappings were rejected")
    ap.add_argument("-r", "--recursive", action="store_true")
    ap.add_argument("--keep-null", action="store_true", help="keep fields whose value is null")
    ap.add_argument("--dry-run", action="store_true", help="only show the mapping choice, write nothing")
    args = ap.parse_args()

    mpath, folder, out = Path(args.mapping), Path(args.input), Path(args.output)
    if not mpath.exists():
        sys.exit(f"Mapping not found: {mpath}")
    if not folder.is_dir():
        sys.exit(f"Input folder not found: {folder}")
    mappings = load_mappings(mpath)
    if args.only:
        wanted = {x.strip() for x in args.only.split(",")}
        mappings = [m for m in mappings if m["name"] in wanted]
        missing = wanted - {m["name"] for m in mappings}
        if missing:
            sys.exit(f"Unknown mapping name(s) in --only: {', '.join(sorted(missing))}")
    if not mappings:
        sys.exit("No usable mapping files found.")
    forced = mpath.is_file()
    files = find_files(folder, args.recursive)
    if not files:
        sys.exit(f"No .xml/.txt files in {folder}")

    # 1) load files
    loaded, report = [], []
    for p in files:
        name = str(p.relative_to(folder)) if args.recursive else p.name
        try:
            el, notes = load_xml(p)
        except Exception as err:  # noqa
            report.append({"file": name, "status": "FAILED", "mappings": [], "note": str(err)})
            print(f"[FAILED]    {name}: {err}")
            continue
        el.set(SRC_ATTR, name)
        loaded.append((name, el, notes))

    # 2) build "documents": one per file, or one per root-element type when combined
    docs = []   # (label, stem, doc_root, [file names], [notes])
    if args.mode == "per-file":
        for name, el, notes in loaded:
            r = etree.Element("__root__")
            r.append(el)
            docs.append((name, Path(name).stem, r, [name], notes))
    else:
        by_type = {}
        for name, el, notes in loaded:
            by_type.setdefault(local(el), []).append((name, el, notes))
        for tag, items in by_type.items():
            r = etree.Element("__root__")
            for _, el, _ in items:
                r.append(el)
            docs.append((f"{len(items)} <{tag}> file(s)", "combined", r,
                         [n for n, _, _ in items], [x for _, _, ns in items for x in ns]))

    # 3) choose the mapping for every document
    plan = []   # (stem, doc_root, mapping)
    for label, stem, doc_root, fnames, notes in docs:
        status = "REPAIRED" if notes else "OK"
        if forced:
            chosen, rejected = [(mappings[0], ["forced with -m"], None)], []
        else:
            accepted, rejected = choose(doc_root, mappings, args.operation)
            chosen = accepted if args.all_matches else accepted[:1]
            if not accepted:
                tops = ", ".join(sorted({local(c) for c in doc_root}))
                msg = f"no mapping matches (top element: <{tops}>)"
                for f in fnames:
                    report.append({"file": f, "status": "UNMATCHED", "mappings": [], "note": msg})
                print(f"[UNMATCHED] {label}: {msg}")
                if args.explain:
                    for n, why in rejected:
                        print(f"             x {n}: {why}")
                continue
        names = [m["name"] for m, _, _ in chosen]
        for f in fnames:
            report.append({"file": f, "status": status, "mappings": names,
                           "why": chosen[0][1], "note": "; ".join(notes)})
        print(f"[{status:10}] {label}  ->  {', '.join(names)}")
        print(f"             why: {'; '.join(chosen[0][1])}")
        if notes:
            print(f"             repaired: {'; '.join(notes)}")
        if not forced and len(chosen) == 1 and len(accepted) > 1:
            print(f"             also fits: {', '.join(m['name'] for m, _, _ in accepted[1:])} (not used; --all-matches to run them)")
        if args.explain:
            for n, why in rejected:
                print(f"             x {n}: {why}")
        for m, _, _ in chosen:
            plan.append((stem, doc_root, m))

    # 4) convert
    if not args.dry_run:
        out.mkdir(parents=True, exist_ok=True)
        finish = (lambda x: x) if args.keep_null else prune
        print()
        for stem, doc_root, mapping in plan:
            template, split, mname = mapping["template"], mapping.get("split"), mapping["name"]
            if split:
                nodes = walk_path(split[1:], doc_root, doc_root)[0]
                for n, node in enumerate(nodes, start=1):
                    suffix = f"_{n}" if len(nodes) > 1 else ""
                    write_json(finish(render(template, node, doc_root)), out / f"{stem}_{mname}{suffix}.json")
            else:
                write_json(finish(render(template, doc_root, doc_root)), out / f"{stem}_{mname}.json")
        (out / "_detection_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")

    counts = {}
    for r in report:
        counts[r["status"]] = counts.get(r["status"], 0) + 1
    print("\nSummary: " + ", ".join(f"{v} {k}" for k, v in counts.items()))


if __name__ == "__main__":
    main()
