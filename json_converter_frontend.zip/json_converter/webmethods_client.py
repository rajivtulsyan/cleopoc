"""
webmethods_client.py - sends the generated JSON to the webMethods MFT REST API.

Endpoints are kept in endpoints.json  (mapping name -> HTTP method + path), so a new mapping
only needs one more entry there (or a row in the app's "Endpoints" table).
A path may contain {field} placeholders that are filled from the top-level field of the JSON
body, e.g.  /mft/api/v1/partners/{id}
"""
import json
import re
import time
from pathlib import Path

import requests

DEFAULT_ENDPOINTS = {
    "add_partner": {"method": "POST", "path": "/mft/api/v1/partners"},
    "create_bulk_partners": {"method": "POST", "path": "/mft/api/v1/partners/bulk"},
    "create_certificate": {"method": "POST", "path": "/mft/api/v1/certificates"},
    "create_bulk_certificates": {"method": "POST", "path": "/mft/api/v1/certificates/bulk"},
}


def load_endpoints(path):
    p = Path(path)
    if p.is_file():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            pass
    return dict(DEFAULT_ENDPOINTS)


def save_endpoints(path, endpoints):
    Path(path).write_text(json.dumps(endpoints, indent=2), encoding="utf-8")


def mask(token):
    if not token:
        return "(empty)"
    return token[:4] + "…****" if len(token) > 8 else "****"


def make_headers(token):
    return {"MCSP-Authorization": token, "content-type": "application/json", "accept": "application/json"}


def build_url(base, path, body):
    """base + path, with {field} placeholders taken from the JSON body. Raises ValueError if one is missing."""
    def fill(m):
        key = m.group(1)
        if not isinstance(body, dict) or body.get(key) in (None, ""):
            raise ValueError(f"endpoint path needs {{{key}}} but the JSON body has no '{key}' field")
        return requests.utils.quote(str(body[key]), safe="")
    return base.strip().rstrip("/") + "/" + re.sub(r"\{(\w+)\}", fill, path.strip()).lstrip("/")


def send_one(method, url, token, body, timeout=30, verify=True):
    """Send one request. Never raises: returns {ok, status, seconds, response, error}."""
    started = time.time()
    try:
        r = requests.request(method.upper(), url, headers=make_headers(token),
                             data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
                             timeout=timeout, verify=verify)
        return {"ok": r.ok, "status": r.status_code, "seconds": round(time.time() - started, 2),
                "response": r.text[:3000], "error": ""}
    except requests.exceptions.SSLError as err:
        return _fail(started, "SSL error (untick 'Verify SSL certificate' only if you trust this server): " + str(err)[:300])
    except requests.exceptions.ConnectionError as err:
        return _fail(started, "Cannot connect - check the base URL, VPN and port: " + str(err)[:300])
    except requests.exceptions.Timeout:
        return _fail(started, f"Timed out after {timeout}s")
    except Exception as err:  # noqa
        return _fail(started, str(err)[:300])


def _fail(started, msg):
    return {"ok": False, "status": None, "seconds": round(time.time() - started, 2), "response": "", "error": msg}
