"""
Cleo XML -> webMethods JSON converter  (Streamlit front end)

Run:   streamlit run app.py
Needs: pip install streamlit lxml
"""
import io
import json
import sys
import zipfile
from pathlib import Path

import pandas as pd
import streamlit as st

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))
import xml_to_json as x2j  # noqa: E402  (the converter engine)
import webmethods_client as wm  # noqa: E402  (sends JSON to the webMethods REST API)

st.set_page_config(page_title="Cleo XML to JSON", page_icon="🔄", layout="wide")

ICON = {"OK": "✅ OK", "REPAIRED": "🛠️ Repaired", "UNMATCHED": "⚠️ No mapping", "FAILED": "❌ Failed",
        "NO_OUTPUT": "⚠️ Nothing produced"}
SAMPLE_DIR = HERE / "samples"


# ----------------------------------------------------------------- helpers
@st.cache_data(show_spinner=False)
def file_summary(data: bytes):
    return x2j.summarize_xml(data)


def as_text(data: bytes, limit=30000):
    t = data.decode("utf-8-sig", errors="replace")
    return t if len(t) <= limit else t[:limit] + f"\n\n... (preview cut, {len(t):,} characters in total)"


def pretty(obj):
    return json.dumps(obj, indent=2, ensure_ascii=False)


def make_zip(res):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for o in res["outputs"]:
            z.writestr(o["file"], pretty(o["data"]))
        report = [{"input": f, "status": d["status"], "mapping": d["mappings"], "why": d["why"]}
                  for d in res["decisions"] for f in d["files"]]
        z.writestr("_detection_report.json", pretty(report))
    return buf.getvalue()


def ss(key, default):
    if key not in st.session_state:
        st.session_state[key] = default
    return st.session_state[key]


ss("extra", {})          # files loaded from samples / a folder
ss("uploader_key", 0)
ss("result", None)
ss("send_log", [])

# ----------------------------------------------------------------- header
st.title("🔄 Cleo XML → webMethods JSON Converter")
st.caption("Load your Cleo XML exports, check which mapping each file will use, convert them, and preview or download the JSON.")

with st.expander("📖 How this works (read me first)", expanded=False):
    st.markdown(
        """
**1 · Input files** – upload the Cleo XML exports (or load the samples / a folder). Each file is checked and
repaired if needed (e.g. a missing quote or a bare `&`).

**2 · Mappings** – a *mapping* is a small JSON recipe that says *"if the XML looks like X, produce JSON shaped like Y"*.
The app compares every file with every mapping's conditions and picks **one** mapping per file. You can see why, and
override the choice for any file. You can also read and edit the mappings here.

**3 · Convert & results** – click **Convert to JSON**. Every output is named `<input file>_<mapping>.json`.
Preview the source XML next to the JSON, and download one file or everything as a ZIP.

**4 · Send to webMethods** – enter the base URL and your `MCSP-Authorization` value, review the exact request, then send
the JSON to the webMethods MFT API and see the response for every file.

**Create vs Update** (sidebar) decides whether the `create_*` or `update_*` mappings are used – the XML itself cannot say
whether a partner already exists in webMethods.
        """
    )

# ----------------------------------------------------------------- sidebar
with st.sidebar:
    st.header("⚙️ Settings")
    mapping_dir = st.text_input("Mapping folder", str(HERE / "mappings"),
                                help="Folder with the mapping .json files. Files starting with _ are ignored.")
    operation = st.radio("API operation", ["create", "update"], horizontal=True,
                         help="create → add_partner, create_bulk_partners, create_certificate …  "
                              "update → update_partner, update_bulk_partners, update_certificate …")
    mode_label = st.radio("Output files",
                          ["One JSON per input file", "Combine files of the same type into one JSON"],
                          help="Combined mode is handy for bulk calls: e.g. 500 single-partner files → one bulk-create JSON.")
    mode = "per-file" if mode_label.startswith("One") else "combined"
    st.divider()
    detect_mode = st.radio("Mapping selection", ["Auto-detect (recommended)", "Use ONE mapping for every file"])
    all_matches = st.checkbox("Run every mapping that fits a file", value=False,
                              help="Off = only the best mapping per file. On = one output per matching mapping.")
    keep_null = st.checkbox("Keep empty (null) fields", value=False,
                            help="Off = fields with no value in the XML are left out of the JSON.")

mdir = Path(mapping_dir)
if not mdir.is_dir():
    st.error(f"Mapping folder not found: {mdir}")
    st.stop()
mappings = x2j.load_mappings(mdir)
if not mappings:
    st.error("No usable mapping files in that folder.")
    st.stop()
by_name = {m["name"]: m for m in mappings}
names = sorted(by_name)

forced = None
if detect_mode.startswith("Use ONE"):
    with st.sidebar:
        forced_name = st.selectbox("Mapping to use", names)
    forced = by_name[forced_name]

# ----------------------------------------------------------------- tabs
tab1, tab2, tab3, tab4 = st.tabs(["① Input files", "② Mappings", "③ Convert & results", "④ Send to webMethods"])

# ================================================================ TAB 1
with tab1:
    st.subheader("Step 1 – Add your Cleo XML files")
    uploaded = st.file_uploader("Drop .xml or .txt files here", type=["xml", "txt"],
                                accept_multiple_files=True, key=f"uploader_{st.session_state.uploader_key}")
    c1, c2, c3 = st.columns([1, 2, 1])
    with c1:
        if st.button("📂 Load sample files"):
            for p in sorted(SAMPLE_DIR.glob("*.xml")):
                st.session_state.extra[p.name] = p.read_bytes()
    with c2:
        folder_in = st.text_input("…or read every .xml/.txt file from a folder on this computer", "",
                                  placeholder=r"C:\Users\me\Downloads\cleo_xml")
        if st.button("Load folder") and folder_in:
            fp = Path(folder_in)
            if fp.is_dir():
                found = x2j.find_files(fp, False)
                for p in found:
                    st.session_state.extra[p.name] = p.read_bytes()
                st.success(f"Loaded {len(found)} file(s).")
            else:
                st.error("Folder not found.")
    with c3:
        if st.button("🗑️ Clear all files"):
            st.session_state.extra = {}
            st.session_state.uploader_key += 1
            st.session_state.result = None
            st.rerun()

    inputs = dict(st.session_state.extra)
    for f in uploaded or []:
        inputs[f.name] = f.getvalue()

    if not inputs:
        st.info("No files yet. Upload some XML files, or click **Load sample files** to try the app.")
    else:
        rows = []
        for n, data in inputs.items():
            s = file_summary(data)
            c = s["counts"]
            rows.append({"File": n, "Size (KB)": round(len(data) / 1024, 1), "Check": ICON[s["status"]],
                         "Top element": s["top"], "Hosts": c.get("Host", 0), "Mailboxes": c.get("Mailbox", 0),
                         "Actions": c.get("Action", 0), "Certificates": c.get("Certificate", 0),
                         "Notes": "; ".join(s["notes"])})
        st.markdown(f"**{len(inputs)} file(s) loaded**")
        st.dataframe(pd.DataFrame(rows), hide_index=True)

        st.markdown("##### Look inside a file")
        pick = st.selectbox("File", list(inputs), label_visibility="collapsed")
        s = file_summary(inputs[pick])
        left, right = st.columns([1, 2])
        with left:
            if s["status"] == "FAILED":
                st.error("This file could not be read: " + "; ".join(s["notes"]))
            else:
                if s["notes"]:
                    st.warning("Automatically repaired: " + "; ".join(s["notes"]))
                st.caption("Elements found in this file")
                st.dataframe(pd.DataFrame(sorted(s["counts"].items()), columns=["Element", "Count"]),
                             hide_index=True)
        with right:
            st.caption("Raw XML")
            st.code(as_text(inputs[pick]), language="xml")

# ================================================================ TAB 2
with tab2:
    st.subheader("Step 2 – Mappings: what will each file be converted with?")
    st.markdown("##### A. Available mappings")
    rows = []
    for m in mappings:
        rows.append({"Mapping": m["name"],
                     "Selection": "Auto" if m.get("auto_detect", True) else "Manual only",
                     "Used when the XML …": x2j.describe_match(m.get("match")),
                     "Output": f"one JSON per {m['split'].lstrip('$/')}" if m.get("split") else "one JSON per file",
                     "Description": m.get("description", "")})
    st.dataframe(pd.DataFrame(rows), hide_index=True)

    with st.expander("🔍 View / edit a mapping"):
        sel = st.selectbox("Mapping", names, key="map_sel")
        m = by_name[sel]
        st.caption("`match` = when it applies · `split` = one JSON per element · `template` = the JSON to produce "
                   "(`$` values are read from the XML).")
        raw = {k: v for k, v in m.items() if k != "_file"}
        edited = st.text_area("Mapping JSON", pretty(raw), height=380, key=f"edit_{sel}")
        b1, b2 = st.columns(2)
        with b1:
            if st.button("💾 Save changes to this mapping"):
                try:
                    obj = json.loads(edited)
                    if "template" not in obj:
                        raise ValueError("a mapping needs a 'template'")
                    Path(m["_file"]).write_text(pretty(obj), encoding="utf-8")
                    st.success(f"Saved {m['_file']}")
                except Exception as err:  # noqa
                    st.error(f"Not saved: {err}")
        with b2:
            new_name = st.text_input("Save as a new mapping named", "", placeholder="my_new_mapping")
            if st.button("➕ Save as new") and new_name.strip():
                try:
                    obj = json.loads(edited)
                    obj["name"] = new_name.strip()
                    (mdir / f"{new_name.strip()}.json").write_text(pretty(obj), encoding="utf-8")
                    st.success(f"Created {new_name.strip()}.json - it appears after the next interaction.")
                except Exception as err:  # noqa
                    st.error(f"Not saved: {err}")

    st.markdown("##### B. Which mapping will each file use?")
    if not inputs:
        st.info("Load some files in step 1 first.")
    else:
        only_forced = forced is not None
        preview = x2j.convert(list(inputs.items()), mappings, operation, mode, None, all_matches, keep_null,
                              forced=forced)
        if mode == "combined":
            st.info("Combined mode: all files of the same type are treated as one document, so the mapping is "
                    "chosen for the whole group (per-file overrides are not available).")
        rows = []
        for d in preview["decisions"]:
            rows.append({"File": d["label"], "Check": ICON[d["status"]],
                         "Auto choice": ", ".join(d["mappings"]) or "—",
                         "Why": "; ".join(d["why"]),
                         "Use mapping": "(auto)"})
        edited_df = st.data_editor(
            pd.DataFrame(rows), hide_index=True, key="override_editor",
            disabled=["File", "Check", "Auto choice", "Why"] if mode == "per-file" and not only_forced
            else ["File", "Check", "Auto choice", "Why", "Use mapping"],
            column_config={"Use mapping": st.column_config.SelectboxColumn(
                "Use mapping (change to override)", options=["(auto)"] + names, required=True)})
        st.session_state.overrides = {
            r["File"]: r["Use mapping"] for _, r in edited_df.iterrows()
            if r["Use mapping"] != "(auto)"} if mode == "per-file" and not only_forced else {}
        if st.session_state.overrides:
            st.success(f"{len(st.session_state.overrides)} file(s) will use a mapping you selected by hand.")

        with st.expander("Why were the other mappings rejected?"):
            for d in preview["decisions"]:
                if d["rejected"]:
                    st.markdown(f"**{d['label']}**")
                    st.dataframe(pd.DataFrame(d["rejected"], columns=["Mapping", "Reason it does not fit"]),
                                 hide_index=True)
                if d["also_fits"]:
                    st.caption("Also fits (not used): " + ", ".join(d["also_fits"]))

# ================================================================ TAB 3
with tab3:
    st.subheader("Step 3 – Convert and check the output")
    if not inputs:
        st.info("Load some files in step 1 first.")
    else:
        sig = (tuple((n, len(b)) for n, b in inputs.items()), operation, mode, all_matches, keep_null,
               forced["name"] if forced else None, tuple(sorted(st.session_state.get("overrides", {}).items())),
               mapping_dir)
        if st.button("🚀 Convert to JSON", type="primary"):
            with st.spinner("Converting…"):
                res = x2j.convert(list(inputs.items()), mappings, operation, mode, None, all_matches, keep_null,
                                  forced=forced, overrides=st.session_state.get("overrides", {}))
            st.session_state.result = {"res": res, "inputs": dict(inputs), "sig": sig}

        R = st.session_state.result
        if R is None:
            st.info("Check steps 1 and 2, then click **Convert to JSON**.")
        else:
            if R["sig"] != sig:
                st.warning("Files or settings changed since the last conversion – click **Convert to JSON** again to refresh.")
            res, src = R["res"], R["inputs"]
            decs = res["decisions"]
            bad = [d for d in decs if d["status"] in ("UNMATCHED", "FAILED", "NO_OUTPUT")]
            m1, m2, m3, m4 = st.columns(4)
            m1.metric("Input files", sum(len(d["files"]) for d in decs))
            m2.metric("JSON files created", len(res["outputs"]))
            m3.metric("No mapping found", sum(len(d["files"]) for d in decs if d["status"] == "UNMATCHED"))
            m4.metric("Failed to read", sum(len(d["files"]) for d in decs if d["status"] == "FAILED"))

            for d in bad:
                if d["status"] == "UNMATCHED":
                    st.warning(f"**{d['label']}** was skipped: {d['why'][0]}. Add or edit a mapping for this kind of XML (step 2).")
                elif d["status"] == "NO_OUTPUT":
                    st.warning(f"**{d['label']}**: mapping {', '.join(d['mappings'])} produced no JSON because the file has nothing it can convert. Pick a different mapping in step 2.")
                else:
                    st.error(f"**{d['label']}** could not be read: {'; '.join(d['notes'])}")

            st.markdown("##### What happened to each file")
            st.dataframe(pd.DataFrame([{
                "Input": d["label"], "Check": ICON[d["status"]], "Mapping used": ", ".join(d["mappings"]) or "—",
                "Why": "; ".join(d["why"]), "Output file(s)": ", ".join(d["outputs"]) or "—"} for d in decs]),
                hide_index=True)

            if res["outputs"]:
                st.download_button("⬇️ Download all JSON files (ZIP)", make_zip(res), "json_output.zip",
                                   "application/zip")
                st.markdown("##### Preview an output file")
                labels = {o["file"]: o for o in res["outputs"]}
                chosen = st.selectbox("Output file", list(labels))
                o = labels[chosen]
                st.caption(f"Created with mapping **{o['mapping']}** from: {', '.join(o['sources'][:5])}"
                           + (" …" if len(o["sources"]) > 5 else ""))
                a, b = st.columns(2)
                with a:
                    st.markdown("**Source XML**")
                    sfile = o["sources"][0]
                    if len(o["sources"]) > 1:
                        sfile = st.selectbox("Source file", o["sources"], key="src_pick")
                    st.code(as_text(src[sfile]), language="xml")
                with b:
                    st.markdown("**Generated JSON**")
                    st.json(o["data"], expanded=True)
                    st.download_button(f"⬇️ Download {chosen}", pretty(o["data"]), chosen, "application/json")
                    with st.expander("Show as plain text"):
                        st.code(pretty(o["data"]), language="json")

# ================================================================ TAB 4
with tab4:
    st.subheader("Step 4 – Send the JSON to webMethods MFT")
    R = st.session_state.result
    ENDPOINT_FILE = HERE / "endpoints.json"
    endpoints = wm.load_endpoints(ENDPOINT_FILE)

    st.markdown("##### A. Connection")
    c1, c2 = st.columns([2, 2])
    with c1:
        base_url = st.text_input("Base URL", "", placeholder="https://your-mft-host:port",
                                 help="Everything before /mft/api/v1/... (no trailing path needed).")
    with c2:
        token = st.text_input("MCSP-Authorization value", "", type="password",
                              help="Sent as the MCSP-Authorization header. It is kept in memory only, never saved to disk.")
    c3, c4, _ = st.columns([1, 1, 2])
    with c3:
        verify_ssl = st.checkbox("Verify SSL certificate", value=True,
                                 help="Untick only for test servers with a self-signed certificate.")
    with c4:
        timeout = st.number_input("Timeout (seconds)", min_value=1, max_value=300, value=30)
    if "/mft/api" in base_url:
        st.warning("The base URL should stop before /mft/api/v1 – that part is added for you from the endpoint table below.")

    with st.expander("🧭 Endpoints (which API call each mapping uses)"):
        st.caption("One row per mapping. Use `{field}` in a path to take a value from the JSON body, "
                   "e.g. `/mft/api/v1/partners/{id}`. Leave the path empty for mappings you do not want to send.")
        ep_df = pd.DataFrame([{"Mapping": n, "Method": endpoints.get(n, {}).get("method", "POST"),
                               "Path": endpoints.get(n, {}).get("path", "")}
                              for n in sorted(set(names) | set(endpoints))])
        ep_edit = st.data_editor(ep_df, hide_index=True, key="endpoint_editor", disabled=["Mapping"],
                                 column_config={"Method": st.column_config.SelectboxColumn(
                                     "Method", options=["POST", "PUT", "PATCH"], required=True)})
        if st.button("💾 Save endpoints"):
            new_ep = {r["Mapping"]: {"method": r["Method"], "path": str(r["Path"]).strip()}
                      for _, r in ep_edit.iterrows() if str(r["Path"]).strip()}
            wm.save_endpoints(ENDPOINT_FILE, new_ep)
            st.success(f"Saved {ENDPOINT_FILE.name}")
            endpoints = new_ep
        endpoints = {r["Mapping"]: {"method": r["Method"], "path": str(r["Path"]).strip()}
                     for _, r in ep_edit.iterrows() if str(r["Path"]).strip()}

    st.markdown("##### B. Choose what to send")
    if R is None or not R["res"]["outputs"]:
        st.info("Create some JSON files in step 3 first.")
    else:
        outs = R["res"]["outputs"]
        done = {r["File"] for r in st.session_state.send_log if r["OK"]}
        sendable = [o for o in outs if o["mapping"] in endpoints]
        no_ep = sorted({o["mapping"] for o in outs if o["mapping"] not in endpoints})
        if no_ep:
            st.warning("No endpoint is configured for: " + ", ".join(no_ep)
                       + ". Add one in the Endpoints table above to be able to send those files.")
        if R["sig"] != (tuple((n, len(b)) for n, b in inputs.items()), operation, mode, all_matches, keep_null,
                        forced["name"] if forced else None,
                        tuple(sorted(st.session_state.get("overrides", {}).items())), mapping_dir):
            st.warning("The files or settings changed since the last conversion – the list below is from the last conversion.")

        resend = st.checkbox("Allow sending files that were already sent successfully in this session", value=False)
        options = [o["file"] for o in sendable if resend or o["file"] not in done]
        picked = st.multiselect("Files to send", options, default=options,
                                help="Only files whose mapping has an endpoint are listed.")
        by_file = {o["file"]: o for o in sendable}

        if picked:
            st.markdown("##### C. Check the request before sending")
            look = st.selectbox("Show the request for", picked)
            o = by_file[look]
            ep = endpoints[o["mapping"]]
            try:
                url = wm.build_url(base_url or "https://<base-url>", ep["path"], o["data"])
                st.code(f"{ep['method']} {url}\n"
                        f"MCSP-Authorization: {wm.mask(token)}\ncontent-type: application/json\naccept: application/json\n\n"
                        + pretty(o["data"]), language="http")
            except ValueError as err:
                st.error(str(err))

            st.markdown("##### D. Send")
            stop_on_error = st.checkbox("Stop at the first error", value=True)
            ready = bool(base_url.strip()) and bool(token.strip())
            if not ready:
                st.info("Enter the base URL and the MCSP-Authorization value to enable sending.")
            confirm = st.checkbox(f"I understand this will send {len(picked)} request(s) to {base_url or '…'} "
                                  "and may create or change data in webMethods.")
            if st.button(f"📤 Send {len(picked)} request(s)", type="primary", disabled=not (ready and confirm)):
                bar = st.progress(0.0)
                new_rows = []
                for i, fname in enumerate(picked, start=1):
                    o = by_file[fname]
                    ep = endpoints[o["mapping"]]
                    try:
                        url = wm.build_url(base_url, ep["path"], o["data"])
                        r = wm.send_one(ep["method"], url, token, o["data"], timeout=timeout, verify=verify_ssl)
                    except ValueError as err:
                        url, r = ep["path"], {"ok": False, "status": None, "seconds": 0, "response": "", "error": str(err)}
                    new_rows.append({"File": fname, "Mapping": o["mapping"], "Method": ep["method"], "URL": url,
                                     "Status": r["status"], "OK": r["ok"], "Seconds": r["seconds"],
                                     "Response": r["response"] or r["error"]})
                    bar.progress(i / len(picked))
                    if stop_on_error and not r["ok"]:
                        break
                st.session_state.send_log = [x for x in st.session_state.send_log
                                             if x["File"] not in {n["File"] for n in new_rows}] + new_rows
                skipped = len(picked) - len(new_rows)
                good = sum(1 for n in new_rows if n["OK"])
                if good == len(new_rows):
                    st.success(f"{good} request(s) succeeded.")
                else:
                    st.error(f"{good} succeeded, {len(new_rows) - good} failed."
                             + (f" {skipped} not sent because 'Stop at the first error' is on." if skipped else ""))

    log = st.session_state.send_log
    if log:
        st.markdown("##### Results")
        df = pd.DataFrame(log)
        df.insert(1, "Result", df["OK"].map({True: "✅ Success", False: "❌ Failed"}))
        st.dataframe(df.drop(columns=["OK"]), hide_index=True)
        pick_resp = st.selectbox("Show the full response for", [r["File"] for r in log])
        row = next(r for r in log if r["File"] == pick_resp)
        st.code(str(row["Response"]) or "(empty response)", language="json")
        d1, d2 = st.columns(2)
        with d1:
            st.download_button("⬇️ Download the send log (JSON)", pretty(log), "send_log.json", "application/json")
        with d2:
            if st.button("🧹 Clear the send log"):
                st.session_state.send_log = []
                st.rerun()
