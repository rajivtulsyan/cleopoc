#!/usr/bin/env python3
"""
cleo_xml_to_excel.py
Reads every Cleo MFT XML export in a folder and builds one Excel workbook:

  Sheet "Data"       one row per XML element, same layout as Book1.xlsx:
                     File Name | Element | Values_Type | Values | Total_Attribute |
                     ATTRIBUTES_key01 | ATTRIBUTES_value01 | key02 | value02 ...
  Sheet "Dashboard"  summary matrix (Host / Mailboxes / Actions / Commands),
                     per-file matrix and a chart. All numbers are Excel formulas
                     over the Data sheet, so they update if you filter/edit.
  Sheet "Parse_Log"  one row per input file: OK / REPAIRED / FAILED + notes.

Values_Type codes (assumption, change in classify() if you want different):
  N = element contains child elements (container, e.g. Host, Mailbox, Action)
  V = element has a text value (e.g. <Address>..</Address>)
  A = element has attributes only (no text, no children)
  E = empty element (no text, no children, no attributes)

Usage:
  python cleo_xml_to_excel.py -i ./xml_input -o cleo_inventory.xlsx
  python cleo_xml_to_excel.py -i ./xml_input -o out.xlsx --recursive --mask
"""
import argparse
import re
import sys
from pathlib import Path

from lxml import etree
from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

FONT = "Arial"
SENSITIVE = ("password", "passwd", "pwd", "pwsd", "pass", "secret", "key", "passphrase")
EXTENSIONS = {".xml", ".txt"}

# Elements counted on the dashboard: (label shown, XML element name)
DASH_ITEMS = [("Host", "Host"), ("Mailboxes", "Mailbox"),
              ("Actions", "Action"), ("Commands", "Commands")]

HEADER_FILL = PatternFill("solid", fgColor="1F3864")
LEVEL_FILL = {"Host": "D9E2F3", "Mailbox": "E2EFDA", "Action": "FFF2CC"}
THIN = Side(style="thin", color="BFBFBF")
BOX = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


# ----------------------------------------------------------------- parsing
def repair_text(raw: str):
    """Fix common problems in Cleo exports. Returns (fixed_text, notes)."""
    notes = []
    # 1) attribute value missing its closing quote, e.g.  class="abc<newline>   alias="x"
    fixed, n = re.subn(r'(\w+="[^"<>\n]*)(\n\s*\w+=")', r'\1"\2', raw)
    if n:
        notes.append(f"closed {n} unterminated attribute quote(s)")
    # 2) bare ampersands such as  ?key1=&user=  (invalid in XML)
    fixed, n = re.subn(r'&(?!(?:amp|lt|gt|quot|apos|#\d+|#x[0-9A-Fa-f]+);)', '&amp;', fixed)
    if n:
        notes.append(f"escaped {n} bare '&'")
    return fixed, notes


def parse_file(path: Path):
    """Return (root_element, status, note). Never raises for bad XML."""
    raw = path.read_bytes().decode("utf-8-sig", errors="replace").strip()
    fixed, notes = repair_text(raw)
    data = fixed.encode("utf-8")  # bytes => encoding declaration is allowed
    try:
        root = etree.fromstring(data, etree.XMLParser(remove_comments=True))
        return root, ("REPAIRED" if notes else "OK"), "; ".join(notes)
    except etree.XMLSyntaxError as first_error:
        try:  # last resort: let libxml2 skip what it cannot understand
            root = etree.fromstring(data, etree.XMLParser(recover=True, remove_comments=True))
            if root is not None:
                notes.append(f"recovered with errors: {first_error}")
                return root, "REPAIRED", "; ".join(notes)
        except etree.XMLSyntaxError:
            pass
        return None, "FAILED", str(first_error)


def classify(el):
    children = [c for c in el if isinstance(c.tag, str)]
    text = (el.text or "").strip()
    if children:
        return "N", ""
    if text:
        return "V", text
    if el.attrib:
        return "A", ""
    return "E", ""


def walk(el, file_name, rows, mask):
    if not isinstance(el.tag, str):  # comments / processing instructions
        return
    vtype, value = classify(el)
    attrs = []
    for k, v in el.attrib.items():
        if mask and any(s in k.lower() for s in SENSITIVE):
            v = "***MASKED***"
        attrs.append((etree.QName(k).localname, v.strip()))
    rows.append({
        "file": file_name,
        "element": etree.QName(el).localname,
        "type": vtype,
        "value": value,
        "total_attr": len(attrs) or None,
        "attrs": attrs,
    })
    for child in el:
        walk(child, file_name, rows, mask)


def find_files(folder: Path, recursive: bool):
    it = folder.rglob("*") if recursive else folder.glob("*")
    return sorted(p for p in it if p.is_file() and p.suffix.lower() in EXTENSIONS)


# ------------------------------------------------------------------ Excel
def style_cell(c, bold=False, color="000000", fill=None, size=10, border=True, align=None):
    c.font = Font(name=FONT, bold=bold, color=color, size=size)
    if fill:
        c.fill = PatternFill("solid", fgColor=fill)
    if border:
        c.border = BOX
    if align:
        c.alignment = align


def build_data_sheet(ws, rows):
    max_attr = max((len(r["attrs"]) for r in rows), default=1) or 1
    headers = ["File Name", "Element", "Values_Type", "Values", "Total_Attribute"]
    for i in range(1, max_attr + 1):
        headers += [f"ATTRIBUTES_key{i:02d}", f"ATTRIBUTES_value{i:02d}"]
    ws.append(headers)
    for c in ws[1]:
        style_cell(c, bold=True, color="FFFFFF", fill="1F3864",
                   align=Alignment(horizontal="center", vertical="center", wrap_text=True))

    for r in rows:
        line = [r["file"], r["element"], r["type"], r["value"] or None, r["total_attr"]]
        for k, v in r["attrs"]:
            line += [k, v]
        ws.append(line)
        fill = LEVEL_FILL.get(r["element"])
        for c in ws[ws.max_row]:
            style_cell(c, fill=fill, align=Alignment(vertical="top"))

    ws.freeze_panes = "C2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(headers))}{ws.max_row}"
    widths = {"A": 16, "B": 18, "C": 12, "D": 45, "E": 16}
    for col, w in widths.items():
        ws.column_dimensions[col].width = w
    for i in range(6, len(headers) + 1):
        ws.column_dimensions[get_column_letter(i)].width = 20 if i % 2 == 0 else 45
    return ws.max_row


def build_dashboard(ws, files, last_row):
    A = f"Data!$A$2:$A${last_row}"
    B = f"Data!$B$2:$B${last_row}"
    ws.sheet_view.showGridLines = False
    ws["A1"] = "Cleo MFT Inventory Dashboard"
    ws["A1"].font = Font(name=FONT, size=16, bold=True, color="1F3864")
    ws["A2"] = "All numbers are formulas over the Data sheet. Files scanned:"
    ws["A2"].font = Font(name=FONT, size=10, italic=True, color="595959")
    ws["D2"] = len(files)
    ws["D2"].font = Font(name=FONT, size=10, bold=True)

    # --- Summary matrix (same idea as the block at the bottom of Book1.xlsx)
    ws["A4"] = "Summary (all files)"
    ws["A4"].font = Font(name=FONT, size=12, bold=True, color="1F3864")
    for col, h in zip("AB", ["Item", "Count"]):
        ws[f"{col}5"] = h
        style_cell(ws[f"{col}5"], bold=True, color="FFFFFF", fill="1F3864")
    r = 6
    for label, tag in DASH_ITEMS:
        ws[f"A{r}"] = label
        ws[f"B{r}"] = f'=COUNTIF({B},"{tag}")'
        style_cell(ws[f"A{r}"])
        style_cell(ws[f"B{r}"], bold=True)
        ws[f"B{r}"].number_format = "#,##0"
        r += 1
    sum_first, sum_last = 6, r - 1

    # --- Matrix per file
    r += 2
    ws[f"A{r}"] = "Matrix by file"
    ws[f"A{r}"].font = Font(name=FONT, size=12, bold=True, color="1F3864")
    r += 1
    hdr = r
    heads = ["File Name"] + [lbl for lbl, _ in DASH_ITEMS] + ["Total Elements"]
    for i, h in enumerate(heads, start=1):
        c = ws.cell(row=hdr, column=i, value=h)
        style_cell(c, bold=True, color="FFFFFF", fill="1F3864",
                   align=Alignment(horizontal="center", wrap_text=True))
    first = hdr + 1
    for f in files:
        r += 1
        ws.cell(row=r, column=1, value=f)
        style_cell(ws.cell(row=r, column=1))
        for i, (_, tag) in enumerate(DASH_ITEMS, start=2):
            c = ws.cell(row=r, column=i, value=f'=COUNTIFS({A},$A{r},{B},"{tag}")')
            style_cell(c)
            c.number_format = "#,##0"
        c = ws.cell(row=r, column=len(heads), value=f"=COUNTIF({A},$A{r})")
        style_cell(c)
        c.number_format = "#,##0"
    last = r
    r += 1
    ws.cell(row=r, column=1, value="TOTAL")
    style_cell(ws.cell(row=r, column=1), bold=True, fill="D9E2F3")
    for i in range(2, len(heads) + 1):
        L = get_column_letter(i)
        c = ws.cell(row=r, column=i, value=f"=SUM({L}{first}:{L}{last})")
        style_cell(c, bold=True, fill="D9E2F3")
        c.number_format = "#,##0"

    ws.column_dimensions["A"].width = 24
    for col in "BCDEF":
        ws.column_dimensions[col].width = 15

    # --- Chart of the summary
    ch = BarChart()
    ch.type = "col"
    ch.title = "Hosts, Mailboxes, Actions and Commands"
    ch.y_axis.title = "Count"
    ch.add_data(Reference(ws, min_col=2, min_row=5, max_row=sum_last), titles_from_data=True)
    ch.set_categories(Reference(ws, min_col=1, min_row=sum_first, max_row=sum_last))
    ch.legend = None
    ch.height, ch.width = 8, 14
    ws.add_chart(ch, "H4")


def build_log_sheet(ws, log):
    ws.append(["File Name", "Status", "Elements Read", "Notes"])
    for c in ws[1]:
        style_cell(c, bold=True, color="FFFFFF", fill="1F3864")
    for row in log:
        ws.append(row)
        for c in ws[ws.max_row]:
            style_cell(c, align=Alignment(vertical="top", wrap_text=True))
        status = ws.cell(row=ws.max_row, column=2)
        if status.value == "FAILED":
            status.fill = PatternFill("solid", fgColor="F8CBAD")
        elif status.value == "REPAIRED":
            status.fill = PatternFill("solid", fgColor="FFF2CC")
    for col, w in zip("ABCD", [28, 12, 15, 90]):
        ws.column_dimensions[col].width = w
    ws.freeze_panes = "A2"


# ------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description="Convert Cleo XML exports to an Excel inventory")
    ap.add_argument("-i", "--input", default="xml_input", help="folder containing the XML files")
    ap.add_argument("-o", "--output", default="cleo_inventory.xlsx", help="output .xlsx path")
    ap.add_argument("-r", "--recursive", action="store_true", help="also read sub-folders")
    ap.add_argument("--mask", action="store_true",
                    help="replace values of password/secret/key-like attributes with ***MASKED***")
    args = ap.parse_args()

    folder = Path(args.input)
    if not folder.is_dir():
        sys.exit(f"Input folder not found: {folder}")
    paths = find_files(folder, args.recursive)
    if not paths:
        sys.exit(f"No .xml/.txt files found in {folder}")

    rows, log, names = [], [], []
    for p in paths:
        name = str(p.relative_to(folder)) if args.recursive else p.name
        root, status, note = parse_file(p)
        if root is None:
            log.append([name, status, 0, note])
            print(f"[FAILED]   {name}: {note}")
            continue
        before = len(rows)
        walk(root, name, rows, args.mask)
        log.append([name, status, len(rows) - before, note])
        names.append(name)
        print(f"[{status:8}] {name}: {len(rows) - before} elements" + (f" ({note})" if note else ""))

    wb = Workbook()
    ws_data = wb.active
    ws_data.title = "Data"
    last_row = build_data_sheet(ws_data, rows)
    ws_dash = wb.create_sheet("Dashboard", 0)   # first tab when the file opens
    build_dashboard(ws_dash, names, last_row)
    build_log_sheet(wb.create_sheet("Parse_Log"), log)
    wb.active = 0
    wb.save(args.output)
    print(f"\nSaved {args.output}: {len(rows)} rows from {len(names)} of {len(paths)} files")


if __name__ == "__main__":
    main()
